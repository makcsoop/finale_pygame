from modul import *


if __name__ == '__main__':
    level = input()
    game_screen, hero = load_another_level(level)
    camera = Camera()
    pygame.display.set_caption('Перемещение героя')
    size = width, height = WINDOW_SIZE
    screen = pygame.display.set_mode(size)
    screen.fill(HERBAL_COLOR)

    run = True
    while run:
        clock.tick(60)
        hero.do_up, hero.do_right, hero.do_down, hero.do_left = False, False, False, False
        for event in pygame.event.get():
            keys = pygame.key.get_pressed()
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                show_fon = False
            if event.type == pygame.KEYDOWN:
                if keys[pygame.K_w] or keys[pygame.K_d] or keys[pygame.K_s] or keys[pygame.K_a]:
                    hero.do_up, hero.do_right, hero.do_down, hero.do_left = False, False, False, False
                    if event.key == pygame.K_w:
                        hero.do_up = True
                    if event.key == pygame.K_d:
                        hero.do_right = True
                    if event.key == pygame.K_s:
                        hero.do_down = True
                    if event.key == pygame.K_a:
                        hero.do_left = True
        if show_fon:
            screen.blit(load_image('fon.jpg'), (0, 0))
            text_coord = 50
            for line in intro_text:
                string_rendered = font.render(line, 1, pygame.Color('black'))
                intro_rect = string_rendered.get_rect()
                text_coord += 10
                intro_rect.top = text_coord
                intro_rect.x = 10
                text_coord += intro_rect.height
                screen.blit(string_rendered, intro_rect)
        else:
            screen.fill('black')
            screen.blit(game_screen, (0, 0))
            # изменяем ракурс камеры
            camera.update(hero)
            # обновляем положение всех спрайтов
            for sprite in all_sprites:
                camera.apply(sprite)
            all_sprites.draw(screen)
            hero_group.draw(screen)
            all_sprites.update()
        pygame.display.flip()
    pygame.quit()
